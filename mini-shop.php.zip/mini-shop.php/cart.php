
<?php
// sunt active variabilele din fileul parinte!

session_start();

$products_in_cart = $_SESSION['cart'] ?? [];  //indexul deschide fileul asta

?>

<?php if(count($products_in_cart) > 0) { ?>
<hr>
<h2>
Items in cart: <?php print count($products_in_cart); ?>
<a href="clear.php"> Delete</a>
<!-- // la click, va lucra fileul clear.php, vom sterge tot din cos -->
</h2>
<?php } else {?>
<?php print "<h2>Your cart is empty</h2>";?>
<?php } ?>

<?php var_dump($products_in_cart) ?>

