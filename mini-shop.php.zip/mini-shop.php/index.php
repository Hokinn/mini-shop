<style>
    body{ margin: 50px;}
    div{ clear: both; border: 1px solid #BBB; padding: 20px; overflow: hidden; margin: 5px;}
    img{ float: left;}
</style>

    <?php include 'cart.php' ?> 
    <!-- today is used autoloaders -->
    <!-- require -->
    <!-- include_once -->
    <!-- require_once -->

    <hr>
    <a href="?curr=EUR">EUR</a>
    <a href="?curr=USD">USD</a>
    <a href="?curr=MDL">MDL</a>

<?php

    $selected_currency = $_GET['curr'] ?? "MDL";  // valuta care o alege utilizatorul (luam din valorile din ajax si le convertam aici)

    // 1) JSON -> array PHP
    // * load file
    // * decode json
    $content = file_get_contents("./database/products.json");
    $products = json_decode($content, true); // true -> sa l formateze in array
    // var_dump($content);
   
    $content = file_get_contents("./database/currencies.json");
    $currencies = json_decode($content, true);
    // var_dump ($currencies);

     ///////////////////////////////procces(currency)/////////////////////////
        foreach($products as &$product){   //unele functii ne dau doar copii, clone, inapoi sa scrim nu putem (ca sa lucram cu orig: &)
            $value = $product['price']['value'];
            $curr = $product['price']['currency'];

            $new_price = $value * $currencies[$curr][$selected_currency];
            // var_dump($new_price);
            $product['price']['currency'] = $selected_currency;
            $product['price']['value'] = $new_price;
        }
    ////////////////////////////////////////////////////////////////////////

?>

<hr>

<?php foreach($products as &$product){ ?>

<div>
    <img src="<?php print $product["photo"] ?>" height="200" alt="phone">
    <h2><?php print $product["name"] ?> (<small><?php print $product["price"]["value"] ?> <?php print $product["price"]["currency"] ?></small>)</h2>

    <a href="add.php?pid=<?php print $product["id"] ?>">Add to cart</a>
    <!-- prin GET mergem -->
    
</div>
    
<?php } ?>

<!-- // 
    1) cind printam lista de producte: 
        gd / image functions, sa aratam 200x200 poze la productele adaugate

    2) unificam elementele din cos, no duplicates! (prin ipul din json)    

    3) sortam productele dupa pret [php multi sort + (keY)]

    4) form input + button (search) "ipho" -> ["iphone", "kiiphoneps"]

    5) la items in card sa ne dea un link (a) summary.php -> foreach(photo, name, price) ----> 

 -->
