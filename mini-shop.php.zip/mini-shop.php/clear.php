<?php

    session_start(); // o deschidem ca sa avem dostup la obiectele din cos
    session_destroy();
    header("location: index.php"); // ne intoarcem la main page!

?>